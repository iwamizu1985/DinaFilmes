package com.dinafilmes.backend;

public enum TipoDenuncia {
    PRECONCEITO,
    DESRESPEITO,
    DISCURSO_DE_ÓDIO,
    SPAM,
    SPOILER
}
