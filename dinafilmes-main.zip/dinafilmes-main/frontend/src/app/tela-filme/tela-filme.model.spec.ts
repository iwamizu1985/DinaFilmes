
import { TelaFilme } from './tela-filme.model';


describe('TelaFilme', () => {
    it('should create an instance', () => {
      expect(new TelaFilme()).toBeTruthy();
    });
  });
  