import { Filme } from './vitrine.model';
import { RouterModule } from '@angular/router';


describe('Filme', () => {
  it('should create an instance', () => {
    expect(new Filme()).toBeTruthy();
  });
});