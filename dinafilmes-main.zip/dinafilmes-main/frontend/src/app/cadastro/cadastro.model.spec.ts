import { Usuario } from './cadastro.model';

describe('Cadastro', () => {
  it('should create an instance', () => {
    expect(new Usuario()).toBeTruthy();
  });
});
