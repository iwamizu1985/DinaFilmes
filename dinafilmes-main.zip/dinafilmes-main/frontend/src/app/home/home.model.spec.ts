import { Filme } from './home.model';

describe('Filme', () => {
  it('should create an instance', () => {
    expect(new Filme()).toBeTruthy();
  });
});
